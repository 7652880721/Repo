// src/pages/About.js
import React, { useState } from 'react';
import EditSection from '../components/EditSection';
import '../App.css'; // or use About.css if you prefer

const About = () => {
  const [text, setText] = useState(
    "Welcome to the About Section. Here we showcase our resort’s features."
  );

  const handleUpdate = (updatedText) => setText(updatedText);

  return (
    <div className="about-container">
      <h2>About Us</h2>
      <EditSection
        component="About"
        field="description"
        value={text}
        onSave={handleUpdate}
      />
    </div>
  );
};

export default About;
