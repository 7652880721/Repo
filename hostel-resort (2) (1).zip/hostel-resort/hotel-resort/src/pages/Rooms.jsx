// src/pages/Rooms.jsx
import React from 'react';
import './Room.css';

const Rooms = () => {
  return (
    <div className="rooms-container">
      <h1>Our Rooms</h1>
      <p>Explore our selection of beautiful, well-furnished rooms perfect for a relaxing stay.</p>

      <div className="room-list">
        <div className="room-card">
          <img src="https://via.placeholder.com/300x200" alt="Room 1" />
          <h3>Deluxe Room</h3>
          <p>$120/night</p>
        </div>
        <div className="room-card">
          <img src="https://via.placeholder.com/300x200" alt="Room 2" />
          <h3>Premium Suite</h3>
          <p>$200/night</p>
        </div>
        <div className="room-card">
          <img src="https://via.placeholder.com/300x200" alt="Room 3" />
          <h3>Family Room</h3>
          <p>$180/night</p>
        </div>
      </div>
    </div>
  );
};

export default Rooms;
