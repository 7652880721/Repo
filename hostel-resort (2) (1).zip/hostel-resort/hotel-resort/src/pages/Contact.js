import React from 'react';
import './Contact.css'; // create file for styling

const Contact = () => (
  <div className="contact-page">
    <h2>Contact Us</h2>
    <p>Have questions? We'd love to hear from you!</p>

    <form className="contact-form">
      <label>
        Name:
        <input type="text" name="name" required />
      </label>

      <label>
        Email:
        <input type="email" name="email" required />
      </label>

      <label>
        Message:
        <textarea name="message" rows="5" required />
      </label>

      <button type="submit">Send Message</button>
    </form>
  </div>
);

export default Contact;
