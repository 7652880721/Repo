import React from 'react';
import Header from '../components/Header';
import EditableSection from '../components/EditSection';

const Home = () => {
  return (
    <div>
      <Header />
      <EditableSection />
    </div>
  );
};

export default Home;
