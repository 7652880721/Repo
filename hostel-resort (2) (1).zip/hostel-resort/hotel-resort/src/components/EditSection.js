import React, { useState } from 'react';
import '../App.css';

const EditableSection = () => {
  const [isEditing, setIsEditing] = useState(false);
  const [heading, setHeading] = useState("Welcome to Royal Resort");
  const [paragraph, setParagraph] = useState("Enjoy your luxury stay with us.");
  const [buttons, setButtons] = useState([
    { text: "Book Now", url: "#" },
    { text: "View Rooms", url: "/rooms" }
  ]);

  const handleEditClick = () => setIsEditing(true);

  const handleSave = () => {
    setIsEditing(false);
    
    // Simulate API call to save data
    fetch("https://jsonplaceholder.typicode.com/posts", {
      method: "POST",
      body: JSON.stringify({ heading, paragraph, buttons }),
      headers: { "Content-Type": "application/json" }
    }).then(() => {
      console.log("Data saved (simulated)");
    });
  };

  const handleButtonChange = (index, field, value) => {
    const newButtons = [...buttons];
    newButtons[index][field] = value;
    setButtons(newButtons);
  };

  return (
    <div className="editable-section">
      {isEditing ? (
        <div className="edit-mode">
          <input
            type="text"
            value={heading}
            onChange={(e) => setHeading(e.target.value)}
          />
          <textarea
            value={paragraph}
            onChange={(e) => setParagraph(e.target.value)}
          />
          {buttons.map((btn, i) => (
            <div key={i} className="edit-button">
              <input
                type="text"
                value={btn.text}
                onChange={(e) => handleButtonChange(i, "text", e.target.value)}
              />
              <input
                type="text"
                value={btn.url}
                onChange={(e) => handleButtonChange(i, "url", e.target.value)}
              />
            </div>
          ))}
          <button onClick={handleSave}>Save</button>
        </div>
      ) : (
        <div className="view-mode">
          <h1>{heading}</h1>
          <p>{paragraph}</p>
          <div className="cta-buttons">
            {buttons.map((btn, i) => (
              <a key={i} href={btn.url} className="cta-btn">{btn.text}</a>
            ))}
          </div>
          <button onClick={handleEditClick} className="edit-btn">Edit Section</button>
        </div>
      )}
    </div>
  );
};

export default EditableSection;
