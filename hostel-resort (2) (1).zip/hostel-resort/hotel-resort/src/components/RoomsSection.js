import React, { useState } from 'react';
import '../App.css';

const RoomsSection = () => {
  const [buttons, setButtons] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [buttonText, setButtonText] = useState('');
  const [buttonUrl, setButtonUrl] = useState('');

  const handleAddClick = () => setShowForm(true);

  const handleSubmit = (e) => {
    e.preventDefault();
    setButtons([...buttons, { text: buttonText, url: buttonUrl }]);
    setButtonText('');
    setButtonUrl('');
    setShowForm(false);
  };

  return (
    <div className="rooms-section">
      <h2>Our Rooms</h2>
      <div className="room-card">Room 1 – Deluxe</div>
      <div className="room-card">Room 2 – Suite</div>

      <div className="cta-buttons">
        {buttons.map((btn, idx) => (
          <a key={idx} href={btn.url} className="cta-btn">{btn.text}</a>
        ))}
      </div>

      <button onClick={handleAddClick} className="add-btn">+ Add Button</button>

      {showForm && (
        <form onSubmit={handleSubmit} className="add-form">
          <input
            type="text"
            placeholder="Button Text"
            value={buttonText}
            onChange={(e) => setButtonText(e.target.value)}
            required
          />
          <input
            type="text"
            placeholder="Button URL"
            value={buttonUrl}
            onChange={(e) => setButtonUrl(e.target.value)}
            required
          />
          <button type="submit">Add</button>
        </form>
      )}
    </div>
  );
};

export default RoomsSection;
